# Fabric_SCF
Service of Chain Finance based on Hyperledger Fabric v2.4
